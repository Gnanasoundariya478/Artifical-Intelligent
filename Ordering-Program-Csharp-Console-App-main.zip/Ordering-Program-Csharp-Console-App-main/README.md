# Ordering-Program-Csharp-Console-App
Simple Ordering program create in C# Console Application
I used one-dimensional array to store data
